create trigger TRG_EMPNO
	before insert
	on EMP
	for each row
begin
select "SEQ_EMP".nextval into :NEW.EMPNO from dual;
end;
